package com.example.navegationapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
